<style>
<?= file_get_contents($cfgClient[$client]["module"]["path"].'cntnd_image/css/cntnd_image.css') ?>
</style>
